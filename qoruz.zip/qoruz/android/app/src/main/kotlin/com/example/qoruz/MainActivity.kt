package com.example.qoruz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
